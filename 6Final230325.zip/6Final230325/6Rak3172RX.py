import serial
import time
import configRX

def send_at_command(ser, command):
    try:
        ser.reset_input_buffer()
        ser.reset_output_buffer()
        print(f"Enviando comando: {command}")
        ser.write((command + '\r\n').encode())
        time.sleep(1)
        response = ser.read_all().decode(errors='ignore')
        return response.strip() or "Sin respuesta"
    except serial.SerialException as e:
        return f"Error de conexión: {e}"
    except Exception as e:
        return f"Error: {e}"

def process_rx_event(response):
    try:
        if "+EVT:RXP2P" in response:
            parts = response.split(":")
            if len(parts) >= 4:
                hex_data = parts[-1].strip()
                print(f"Datos codificados (hexadecimal): {hex_data}")

                # Convertir el dato hexadecimal a bytes
                byte_data = bytes.fromhex(hex_data)
                print(f"Datos decodificados (bytes): {byte_data}")
                return byte_data
        return "Evento no reconocido o sin datos."
    except ValueError:
        return f"Datos no válidos para conversión: {response}"
    except Exception as e:
        return f"Error procesando evento: {e}"

if __name__ == "__main__":
    print("Configurando módulo como receptor P2P...")

    try:
        with serial.Serial(configRX.PORT, configRX.BAUDRATE, timeout=5) as ser:
            send_at_command(ser, "AT+NWM=0")
            send_at_command(ser, "AT+P2P=915000000,7,125,1,14,8")

            print("Esperando mensajes del transmisor...")
            send_at_command(ser, "AT+PRECV=65534")

            while True:
                response = send_at_command(ser, "AT+RECV=?")
                if "+EVT:RXP2P" in response:
                    process_rx_event(response)
                else:
                    print(f"Respuesta inesperada: {response}")

                time.sleep(1)
    except serial.SerialException as e:
        print(f"Error al abrir el puerto serie: {e}")