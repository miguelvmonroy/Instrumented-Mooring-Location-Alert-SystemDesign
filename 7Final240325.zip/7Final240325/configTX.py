# config.py
# Configuración del puerto y velocidad
PORT = 'COM4'  # Cambia según tu puerto detectado
BAUDRATE = 115200  # Velocidad predeterminada del módulo